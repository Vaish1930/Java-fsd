package methods;

// Writing a program in Java to verify implementations of methods and ways of calling a method
// Implementing Methods

public class Test {
    static void display() {
        System.out.println("Methods in java");
    }

    public static void main(String[] args) {
        display();
    }
}

// There are two ways to call a function in java
// 1. Call by Value
// 2. Call by reference