package object_oriented_implementation;

class Parent {
    void learning() {
        System.out.println("Learning");
    }

    void talking() {
        System.out.println("Talking");
    }

}
